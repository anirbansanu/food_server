-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Mar 18, 2022 at 06:37 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ecom`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `phone` varchar(13) NOT NULL,
  `email` varchar(255) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `f_name` varchar(255) NOT NULL,
  `l_name` varchar(255) NOT NULL,
  `address` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `phone`, `email`, `pass`, `f_name`, `l_name`, `address`) VALUES
(1, '861747638', 'a@gmail.com', '123', 'ani', 'mukherjee', 'vill+post: andal gram,Dist. : Burdwan,Pin:713321');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `cat_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `cat_name`) VALUES
(1, 'Car'),
(2, 'Bikes'),
(3, 'Electronics');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `brand_name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `file` varchar(255) DEFAULT NULL,
  `fileone` varchar(255) DEFAULT NULL,
  `filetwo` varchar(255) DEFAULT NULL,
  `filethree` varchar(255) DEFAULT NULL,
  `filefour` varchar(255) DEFAULT NULL,
  `price` double NOT NULL,
  `purchasing_date` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `views` bigint(20) DEFAULT NULL,
  `seller_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `brand_name`, `description`, `file`, `fileone`, `filetwo`, `filethree`, `filefour`, `price`, `purchasing_date`, `date`, `views`, `seller_id`, `category_id`) VALUES
(43, 'yipamij841', 'hhhh', 'esfh dfhb dehb dehf edhbf nb ', 'products/images-1644814279974-Screenshot from 2022-02-11 18-58-39.png', 'products/images-1644814279990-xiaomi-redmi-note-5-pro-001.jpg', 'products/images-1644814279994-mi-redmi-note-5-pro-black-500x500.png', 'products/images-1644814280012-miui9_phone.png', '', 34224, '\r\n        8/12/2021', '2022-02-14', NULL, 1, 2),
(44, 'lom', 'hhhh', 'akihfb ewiuosh wo;sih soihj ow;sihje ', 'products/images-1644815276251-miui9_phone.png', 'products/images-1644815276295-Project-Management-Tips-on-How-to-Motivate-Your-Remote-Team-1-1.png', '', '', '', 980, '\r\n        6/10/2021', '2022-02-14', NULL, 1, 3),
(71, 'sugghub', 'hhhh', 'cghnj xfgj', 'products/images-1645284861240-Project-Management-Tips-on-How-to-Motivate-Your-Remote-Team-1-1.png', '', '', '', '', 74333, '10/11/2021', '2022-02-19', NULL, 19, 2),
(75, 'inspiron', 'Dell', 'this is a laptop', 'products/images-1645378009129-Screenshot from 2022-02-20 11-04-32.png', 'products/images-1645378009152-xiaomi-redmi-note-5-pro-001.jpg', 'products/images-1645378009165-miui9_phone.png', 'products/images-1645378009174-avatar2.jpg', '', 34432, '9/11/2021', '2022-02-20', NULL, 19, 3);

-- --------------------------------------------------------

--
-- Table structure for table `query`
--

CREATE TABLE `query` (
  `id` int(11) NOT NULL,
  `query` text NOT NULL,
  `date` date NOT NULL,
  `time` varchar(8) NOT NULL,
  `sender_id` int(11) NOT NULL,
  `receiver_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `u_id` int(11) NOT NULL,
  `f_name` varchar(255) NOT NULL,
  `l_name` varchar(255) NOT NULL,
  `phone` varchar(13) NOT NULL,
  `email` varchar(255) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `file` varchar(255) DEFAULT NULL,
  `district` varchar(255) NOT NULL,
  `state` varchar(255) DEFAULT NULL,
  `city` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`u_id`, `f_name`, `l_name`, `phone`, `email`, `pass`, `file`, `district`, `state`, `city`) VALUES
(1, 'user1', ' ram', '1234567890', 'u@gmail.com', '123', NULL, 'burdwan', 'West Bengal', 'userCity'),
(2, 'usr2', 'usr2', '9876543210', 'usr2@gmail.com', '123', NULL, 'Kolkata', 'West Bengal', 'Kolkata'),
(3, 'Sahil', 'Kumar', '1234567890', 'sahilazm@gmail.com', '1234', NULL, 'Burdwan', 'West Bengal', 'Durgapur'),
(11, 'Rahul', 'Gorai', '1234567890', 'rahul@gmail.com', '123', 'profile/images-1644394442199-AnirbanMukherjeejpg.jpg', 'burdwan', 'West Bengal', 'Andal'),
(12, 'Rahul', 'Gorai', '1234567890', 'rahul@gmail.com', '123', 'profile/images-1644394624716-AnirbanMukherjeejpg.jpg', 'burdwan', 'West Bengal', 'Andal'),
(13, 'anirban', 'mukhejre', '8617476384', 'u@gmail.com', 'a', 'profile/image-1644434108263-01-240x300.jpg', 'a', 'West Bengal', 'Andal Gram'),
(14, 'anirban', 'mukhejre', '8617476384', 'u@gmail.com', 'a', 'profile/image-1644434295697-01-240x300.jpg', 'a', 'West Bengal', 'Andal Gram'),
(15, 'sad', 'sss', '8617476384', 'u@gmail.com', '1', 'profile/image-1644478150188-avatar2.jpg', 'Paschim Bardhaman', 'NEAR OF DURGA TEMPLE', 'DURGAPUR'),
(16, 'anirban', 'mukhejre', '8617476384', 'u@gmail.com', 's', 'profile/image-1644522481674-Project-Management-Tips-on-How-to-Motivate-Your-Remote-Team-1-1.png', 'Paschim Bardhaman', 'NEAR OF DURGA TEMPLE', 'DURGAPUR'),
(17, 'anirban', 'mukhejre', '8617476384', 'u@gmail.com', 's', 'profile/image-1644522630980-Screenshot from 2022-01-28 19-28-41.png', 'Paschim Bardhaman', 'NEAR OF DURGA TEMPLE', 'DURGAPUR'),
(18, 'anirban', 'mukhejre', '8617476384', 'u@gmail.com', '1', 'profile/image-1644522766100-2022_2image_15_13_475502019men-ll.jpg', '1', '1', '1'),
(19, 'sahil', 'mukhejre', '1234567890', 'a@lmail.com', '123', 'profile/image-1644768176395-mi-redmi-note-5-pro-black-500x500.png', 'Paschim Bardhaman', 'NEAR OF DURGA TEMPLE', 'DURGAPUR');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cat_ind` (`category_id`),
  ADD KEY `seller_ind` (`seller_id`);

--
-- Indexes for table `query`
--
ALTER TABLE `query`
  ADD PRIMARY KEY (`id`),
  ADD KEY `buyer_id_ind` (`sender_id`),
  ADD KEY `product_id_ind` (`product_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`u_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=76;

--
-- AUTO_INCREMENT for table `query`
--
ALTER TABLE `query`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `u_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `fk_cat` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_seller` FOREIGN KEY (`seller_id`) REFERENCES `users` (`u_id`) ON DELETE CASCADE;

--
-- Constraints for table `query`
--
ALTER TABLE `query`
  ADD CONSTRAINT `fk_buyer_id` FOREIGN KEY (`sender_id`) REFERENCES `users` (`u_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_product_id` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
